from django.urls import path
from . import views
from django.conf.urls import handler404

urlpatterns = [
    path('', views.home, name='home'),
    path('home', views.home, name='home'),
    path('home_prediction', views.home_prediction, name='home_prediction'),
    path('metric-train', views.metricsTrain, name='metric-train'),
    path('infomodal', views.infomodal, name='infomodal'),
    path('metric-create', views.metricsCreate, name='metric-create'),
    path('metric-delete/<int:id>', views.metricsDelete, name='metric-delete'),
    path('list-info/<int:id>', views.listInfo, name='list-info'),
    path('download_csv/<int:id>', views.download_csv, name='download_csv'),
    path('train_model', views.train_model, name='train_model'),
    path('register', views.register, name='register'),
    path('enter', views.enter, name='enter'),
    path('sair/', views.sair_view, name='sair'),
    path('upload_csv', views.upload_csv, name='upload_csv')

]


