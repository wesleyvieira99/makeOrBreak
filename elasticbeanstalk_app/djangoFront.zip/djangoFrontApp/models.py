from django.db import models

# Create your models here.
class Metrics(models.Model):
    nome = models.CharField(db_column='nome', max_length=100, blank=False)
    categoria = models.CharField(db_column='categoria', max_length=100, blank=False)


# Create your models here.
class MetricsValues(models.Model):

    metrica = models.ForeignKey(Metrics, on_delete=models.CASCADE)
    valor = models.IntegerField(db_column='valor', blank=False)
    tempo = models.IntegerField(db_column='tempo', blank=False)
    decisao = models.IntegerField(db_column='decisao', blank=False)
    cadastrado_por = models.CharField(db_column='cadastrado_por', max_length=100, blank=False, default='wes')



