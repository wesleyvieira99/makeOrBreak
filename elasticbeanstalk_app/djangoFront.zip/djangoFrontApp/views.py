from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.http import QueryDict

from .models import Metrics, MetricsValues
from .forms import MetricsForm, MetricsValuesForm
from django.db.models import Count
from django.core.paginator import Paginator
from .filters import MetricsFilter

from django.urls import reverse

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import joblib
import os.path
import csv

import io
import base64
import seaborn as sns
import matplotlib.pyplot as plt

from django.contrib.auth.decorators import login_required

#Home para casos sem predição
@login_required
def home(request):
    metricshome = Metrics.objects.all()
    contextHome = {
        'metrics': metricshome,
        'nome_usuario': request.user.username
    }
    return render(request, 'home.html', contextHome)


def exec_train():
    metrics_values = MetricsValues.objects.all()
    # Transformar os dados em um dataframe do Pandas
    df = pd.DataFrame([(m.metrica_id, m.valor, m.tempo, m.decisao) for m in metrics_values],
                      columns=['metrica_id', 'valor', 'tempo', 'decisao'])

    # Separar as variáveis independentes (X) da variável dependente (y)
    X = df.drop('decisao', axis=1)
    y = df['decisao']

    # Dividir os dados em conjuntos de treino e teste
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Criar o modelo DecisionTree
    model = DecisionTreeClassifier()

    # Treinar o modelo com os dados de treino
    model.fit(X_train, y_train)

    # Fazer previsões com os dados de teste
    y_pred = model.predict(X_test)

    # Calcular a acurácia do modelo
    accuracy = accuracy_score(y_test, y_pred) * 100
    print(f'Acurácia: {accuracy:.2f}')

    return model, accuracy


def train_model(request):
    if request.method == 'POST':
        try:
            model, accuracy = exec_train()
            # Salvar o modelo treinado em um arquivo para uso futuro
            joblib.dump(model, 'model.joblib')
            print('treinado com sucesso!')

            # obter a rota atual
            url_name = request.resolver_match.url_name
            # redirecionar para a view correspondente com o parâmetro "mensagem_toast"
            if url_name == 'home':
                return redirect(reverse('home') + '?mensagem_toast=sucesso')
            else:
                # redirecionar para a home por padrão se a rota atual não estiver mapeada
                return redirect(reverse('metric-train') + '?mensagem_toast=sucesso')

        except:
            # Retorne uma mensagem de erro para o usuário
            return redirect(reverse('metric-train') + '?mensagem_toast=erro')
    else:
        return render(request, 'metric-train.html')

@login_required
def home_prediction(request):
    # Carregar o modelo treinado a partir do arquivo
    if not os.path.exists('model.joblib'):
        return redirect(reverse('metric-train') + '?mensagem_toast=erro')
    model = joblib.load('model.joblib')

    ############APÓS O TREINO, E MEDIÇÃO DA ACURÁCIA, FAZER PREDIÇÃO COM DADOS ENVIADOS PELO USUÁRIO#####
    if request.method == 'POST':
        try:
            # Pegue os dados do usuário do formulário
            metrica_id = request.POST.get('metrica_id')
            valor = request.POST.get('valor')
            tempo = request.POST.get('tempo')

            countDados = MetricsValues.objects.filter(metrica_id=metrica_id).count()
            if countDados == 0:
                return redirect(reverse('home') + '?mensagem_toast=warning')

            # Crie um objeto MetricsValues a partir dos dados do usuário
            metrica = MetricsValues(metrica_id=metrica_id, valor=valor, tempo=tempo)

            # Adicione o objeto MetricsValues a uma lista de objetos
            data = [metrica]
            # Crie um dataframe a partir da lista de objetos
            df = pd.DataFrame([vars(i) for i in data])
            # Faça a predição utilizando o modelo DecisionTree
            prediction = model.predict(df[['metrica_id', 'valor', 'tempo']])
            # Converta a predição para um formato legível (0 ou 1)
            decisao_prediction = prediction
            # Calcule a acurácia da predição

            metrics = Metrics.objects.all()
            metricsValues = MetricsValues.objects.filter(metrica_id=metrica_id).values('valor', 'tempo', 'decisao')
            # Crie um novo dataframe contendo as variáveis valor, tempo e decisão
            df_plot = pd.DataFrame(list(metricsValues.values('valor', 'tempo', 'decisao')))

            execucacaoTreino = exec_train()
            accuracy = f'{execucacaoTreino[1]:.2f}'

            # Cria o gráfico de Pairplot
            sns.set(style="ticks")
            sns.pairplot(df_plot[['valor', 'tempo', 'decisao']], height=2.5)
            # Salve a figura em memória como um objeto BytesIO
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            # Converta a imagem em formato base64
            image_base64 = base64.b64encode(buffer.getvalue()).decode()

            # cria um QueryDict para passar as variáveis na URL, assim após predizer, voltar pra home com os dados

            data= {
                'decisao_prediction': decisao_prediction,
                'accuracy': accuracy,
                'image_base64': image_base64,
                'metrica_id': metrica_id,
                'valor': valor,
                'tempo': tempo,
                'metrics': metrics,
                'nome_usuario': request.user.username
            }

            # Renderize o template home e passe o contexto para ele com os dados
            return render(request, 'home.html', data)
        except Exception as e:
            # Retorne uma mensagem de erro para o usuário
            return redirect(reverse('home') + '?mensagem_toast=erro')
    else:
        return render(request, 'home.html')


def infomodal(request):
    if request.method == 'POST':
        form = MetricsValuesForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                # Chamar a função para treinar o modelo no início do aplicativo
                model = form.instance
                # mostra mensagem de sucesso
                return redirect(reverse('metric-train') + '?mensagem_toast=sucesso')
            except Exception as e:
                return redirect(reverse('metric-train') + '?mensagem_toast=erro')
        else:
            return redirect(reverse('metric-train') + '?mensagem_toast=erro')
    else:
        form = MetricsValuesForm()
    return render(request, 'metric-train.html', {'form': form})


def contador():
    metrica_counts = MetricsValues.objects.values('metrica_id').annotate(total=Count('metrica_id'))
    return metrica_counts

@login_required
def metricsTrain(request):
    metrics = Metrics.objects.all()
    # filtro
    filter = MetricsFilter(request.GET, queryset=Metrics.objects.all())
    paginator = Paginator(filter.qs, 5)
    # Obtenha o número da página atual da solicitação
    pagina = request.GET.get('pagina')
    # Obtenha os objetos a serem exibidos na página atual
    metrics_paginadas = paginator.get_page(pagina)

    # filtro
    filter = MetricsFilter(request.GET, queryset=Metrics.objects.all())

    metricsValues = MetricsValues.objects.all()
    formTrain = MetricsValuesForm()
    metricsIdcount = contador()

    context = {"metrics": metrics, "metrics_paginadas": metrics_paginadas, 'filter': filter,
               "formTrain": formTrain, "metricsValues": metricsValues,
               'metricsIdcount': metricsIdcount, 'nome_usuario': request.user.username}

    return render(request, 'metric-train.html', context)

@login_required
def metricsCreate(request):
    if request.method == "POST":
        form = MetricsForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                # mostra mensagem de sucesso
                return redirect(reverse('metric-train') + '?mensagem_toast=sucesso')
            except:
                pass
    else:
        form = MetricsForm()
    return render(request, 'metric-create.html', {'form': form, 'nome_usuario': request.user.username})

@login_required
def metricsDelete(request, id):
    metric = Metrics.objects.get(id=id)
    try:
        metric.delete()
        return redirect(reverse('metric-train') + '?mensagem_toast=sucesso')
    except Metrics.DoesNotExist:
        return HttpResponse('A instância de Metrics não existe')
    except Exception as e:
        return HttpResponse('Erro ao deletar a instância de Metrics: {}'.format(str(e)))

@login_required
def handlerNotFound(request, exception):
    return render(request, "handlerNotFound.html")

#Deixando o login required so para as paginas, o que é chamdo dentro dela já está garantido pela segurança da propria pagina em si
# AUTENTICAÇÃO E REGISTRO /////////////


from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login



def register(request):
    if request.method == "POST":
        email = request.POST.get('inputEmail')
        username = request.POST.get('inputUser')
        password = request.POST.get('inputPwd')

        if not username or not email or not password:
            return redirect(reverse('register') + '?mensagem_toast=authErro')
        else:
            user = User.objects.filter(username=username).first()
            if user:
                return redirect(reverse('enter') + '?mensagem_toast=authWarning')
            else:
                user = User.objects.create_user(username, email, password)
                user.save()
                return redirect(reverse('enter') + '?mensagem_toast=authSucesso')
    else:
        return render(request, 'auth/register.html')


def enter(request):
    if request.method == "POST":
        inputUser = request.POST['inputUser']
        inputPwd = request.POST['inputPwd']
        user = authenticate(request, username=inputUser, password=inputPwd)

        if user is None:
            return redirect(reverse('enter') + '?mensagem_toast=authErro')
        else:
            login(request, user)
            return redirect('home')
    else:
        return render(request, 'auth/enter.html')

@login_required()
def upload_csv(request):
    if request.method == 'POST' and request.FILES['csv_file']:
        metrica_id = request.POST['metrica_id']
        csv_file = request.FILES['csv_file']
        if not csv_file.name.endswith('.csv'):
            print("não é um CSV")
            return redirect(reverse('metric-train') + '?mensagem_toast=erro', status=400)
        else:
            if request.POST['delimiter'] == "virgula":
                df = pd.read_csv(csv_file, delimiter=',')
            elif request.POST['delimiter'] == "pontoevirgula":
                df = pd.read_csv(csv_file, delimiter=';')
            else:
                return redirect(reverse('metric-train') + '?mensagem_toast=erro', status=400)
            try:
                header = df.columns.tolist()
                if header != ['valor', 'decisao', 'tempo']:
                    print("não é um CAMPO aceito")
                    print(header)
                    return redirect(reverse('metric-train') + '?mensagem_toast=erro', status=400)
                else:
                    for index, row in df.iterrows():
                        if all(str(x).isdigit() for x in row):
                            infosMetric = MetricsValues(
                                valor=row[0],
                                decisao=row[1],
                                metrica_id=metrica_id,
                                tempo=row[2],
                                cadastrado_por= request.user.username
                            )
                            infosMetric.save()
                        else:
                            print("não é iterou legal nos valores")
                            return redirect(reverse('metric-train') + '?mensagem_toast=erro', status=400)
                    return redirect(reverse('metric-train') + '?mensagem_toast=sucesso')
            except csv.Error:
                print("erro ao ler o CSV")
                return redirect(reverse('metric-train') + '?mensagem_toast=erro', status=400)
    print("erro no envio do CSV")
    return redirect(reverse('metric-train') + '?mensagem_toast=erro', status=400)

@login_required()
def listInfo(request, id):
    infoMetrics = MetricsValues.objects.filter(metrica_id=id)

    context = {
        'infoMetrics': infoMetrics,
        'nome_usuario': request.user.username
    }
    return render(request, 'list-info.html', context)




def download_csv(request, id):
    infoMetrics = MetricsValues.objects.filter(metrica_id=id)

    # Cria a resposta HTTP e adiciona o nome do arquivo
    response = HttpResponse(content_type='text/csv')
    nome_arquivo = f'dados_{id}.csv'
    response['Content-Disposition'] = f'attachment; filename="{nome_arquivo}"'

    # Cria o objeto writer do CSV e escreve os dados
    writer = csv.writer(response)
    writer.writerow(['valor', 'decisao', 'tempo', 'cadastrado_por'])
    for i in infoMetrics:
        writer.writerow([i.valor, i.decisao, i.tempo, i.cadastrado_por])
    return response



from django.contrib.auth import logout
@login_required
def sair_view(request):
    logout(request)
    return redirect('enter')
